create definer = root@`%` view course_published_count as (select `p`.`count` AS `count`, `p`.`id` AS `id`
                                                          from ((select count(0) AS `count`, `c`.`id` AS `id`
                                                                 from `moshi`.`course` `c`
                                                                        join `moshi`.`article` `a`
                                                                 where ((`c`.`courseType` = 1) and
                                                                        (`c`.`id` = `a`.`courseId`) and
                                                                        ((`a`.`status` & (1 << 1)) <> 0))
                                                                 group by `c`.`id`)
                                                                union
                                                                (select count(0) AS `count`, `c`.`id` AS `id`
                                                                 from `moshi`.`course` `c`
                                                                        join `moshi`.`paragraph` `p`
                                                                        join `moshi`.`section` `s`
                                                                 where ((`c`.`courseType` = 2) and
                                                                        (`c`.`id` = `s`.`courseId`) and
                                                                        (`s`.`id` = `p`.`sectionId`) and
                                                                        ((`p`.`status` & (1 << 1)) <> 0))
                                                                 group by `c`.`id`)) `p`);

