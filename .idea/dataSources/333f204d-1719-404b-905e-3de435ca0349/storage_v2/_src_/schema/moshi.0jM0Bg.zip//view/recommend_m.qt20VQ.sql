create view recommend_m as (select `moshi`.`recommend`.`id`          AS `id`,
                                   `moshi`.`recommend`.`image`       AS `image`,
                                   `moshi`.`recommend`.`title`       AS `title`,
                                   `moshi`.`recommend`.`content`     AS `content`,
                                   `moshi`.`recommend`.`createAt`    AS `createAt`,
                                   `moshi`.`recommend`.`status`      AS `status`,
                                   `moshi`.`recommend`.`contentType` AS `contentType`
                            from `moshi`.`recommend`);

