create definer = root@`%` view temp as (select `a`.`id` AS `id`
                                        from `moshi`.`article` `a`
                                               join (select min(`a`.`id`) AS `id`
                                                     from `moshi`.`article` `a`
                                                     group by `a`.`courseId`) `idt`
                                        where ((`a`.`id` >= `idt`.`id`) and (`a`.`id` < (`idt`.`id` + 3)))
                                        order by `a`.`id`);

