create definer = root@`%` view coupon_l as (select `moshi`.`coupon`.`id`        AS `id`,
                                                   `moshi`.`coupon`.`value`     AS `value`,
                                                   `moshi`.`coupon`.`valueType` AS `valueType`,
                                                   `moshi`.`coupon`.`accountId` AS `accountId`,
                                                   `moshi`.`coupon`.`refId`     AS `refId`,
                                                   `moshi`.`coupon`.`refType`   AS `refType`,
                                                   `moshi`.`coupon`.`createAt`  AS `createAt`,
                                                   `moshi`.`coupon`.`offerTo`   AS `offerTo`,
                                                   `moshi`.`coupon`.`status`    AS `status`
                                            from `moshi`.`coupon`);

