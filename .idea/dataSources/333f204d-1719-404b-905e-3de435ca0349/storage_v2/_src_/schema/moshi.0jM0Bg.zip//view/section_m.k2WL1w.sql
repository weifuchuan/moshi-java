create definer = root@`%` view section_m as (select `moshi`.`section`.`id`        AS `id`,
                                                    `moshi`.`section`.`courseId`  AS `courseId`,
                                                    `moshi`.`section`.`accountId` AS `accountId`,
                                                    `moshi`.`section`.`title`     AS `title`,
                                                    `moshi`.`section`.`createAt`  AS `createAt`,
                                                    `moshi`.`section`.`status`    AS `status`
                                             from `moshi`.`section`);

