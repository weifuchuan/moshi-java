create definer = root@`%` view article_m as (select `moshi`.`article`.`id`          AS `id`,
                                                    `moshi`.`article`.`courseId`    AS `courseId`,
                                                    `moshi`.`article`.`title`       AS `title`,
                                                    `moshi`.`article`.`content`     AS `content`,
                                                    `moshi`.`article`.`publishAt`   AS `publishAt`,
                                                    `moshi`.`article`.`createAt`    AS `createAt`,
                                                    `moshi`.`article`.`status`      AS `status`,
                                                    `moshi`.`article`.`audioId`     AS `audioId`,
                                                    `moshi`.`article`.`contentType` AS `contentType`,
                                                    `moshi`.`article`.`summary`     AS `summary`,
                                                    `moshi`.`article`.`coverImage`  AS `coverImage`
                                             from `moshi`.`article`);

