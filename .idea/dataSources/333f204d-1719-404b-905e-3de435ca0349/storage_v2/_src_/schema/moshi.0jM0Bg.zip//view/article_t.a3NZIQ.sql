create view article_t as (select `moshi`.`article`.`id`          AS `id`,
                                 `moshi`.`article`.`courseId`    AS `courseId`,
                                 `moshi`.`article`.`title`       AS `title`,
                                 `moshi`.`article`.`content`     AS `content`,
                                 `moshi`.`article`.`publishAt`   AS `publishAt`,
                                 `moshi`.`article`.`createAt`    AS `createAt`,
                                 `moshi`.`article`.`status`      AS `status`,
                                 `moshi`.`article`.`audioId`     AS `audioId`,
                                 `moshi`.`article`.`contentType` AS `contentType`
                          from `moshi`.`article`);

