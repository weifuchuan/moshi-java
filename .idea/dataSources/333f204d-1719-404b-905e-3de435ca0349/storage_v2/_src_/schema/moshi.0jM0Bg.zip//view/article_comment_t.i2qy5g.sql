create definer = root@`%` view article_comment_t as (select `moshi`.`article_comment`.`id`        AS `id`,
                                                            `moshi`.`article_comment`.`articleId` AS `articleId`,
                                                            `moshi`.`article_comment`.`accountId` AS `accountId`,
                                                            `moshi`.`article_comment`.`content`   AS `content`,
                                                            `moshi`.`article_comment`.`createAt`  AS `createAt`,
                                                            `moshi`.`article_comment`.`status`    AS `status`,
                                                            `moshi`.`article_comment`.`replyTo`   AS `replyTo`
                                                     from `moshi`.`article_comment`);

