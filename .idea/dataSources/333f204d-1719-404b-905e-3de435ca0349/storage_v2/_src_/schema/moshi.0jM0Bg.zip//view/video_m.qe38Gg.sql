create definer = root@`%` view video_m as (select `moshi`.`video`.`id`        AS `id`,
                                                  `moshi`.`video`.`resource`  AS `resource`,
                                                  `moshi`.`video`.`recorder`  AS `recorder`,
                                                  `moshi`.`video`.`accountId` AS `accountId`,
                                                  `moshi`.`video`.`status`    AS `status`,
                                                  `moshi`.`video`.`name`      AS `name`,
                                                  `moshi`.`video`.`uploadAt`  AS `uploadAt`
                                           from `moshi`.`video`);

