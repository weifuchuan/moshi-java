create definer = root@`%` view issue_t as (select `moshi`.`issue`.`id`        AS `id`,
                                                  `moshi`.`issue`.`courseId`  AS `courseId`,
                                                  `moshi`.`issue`.`accountId` AS `accountId`,
                                                  `moshi`.`issue`.`title`     AS `title`,
                                                  `moshi`.`issue`.`openAt`    AS `openAt`,
                                                  `moshi`.`issue`.`closerId`  AS `closerId`,
                                                  `moshi`.`issue`.`closeAt`   AS `closeAt`,
                                                  `moshi`.`issue`.`status`    AS `status`
                                           from `moshi`.`issue`);

