create definer = root@`%` view application_m as (select `moshi`.`application`.`id`          AS `id`,
                                                        `moshi`.`application`.`accountId`   AS `accountId`,
                                                        `moshi`.`application`.`category`    AS `category`,
                                                        `moshi`.`application`.`title`       AS `title`,
                                                        `moshi`.`application`.`content`     AS `content`,
                                                        `moshi`.`application`.`createAt`    AS `createAt`,
                                                        `moshi`.`application`.`status`      AS `status`,
                                                        `moshi`.`application`.`reply`       AS `reply`,
                                                        `moshi`.`application`.`refId`       AS `refId`,
                                                        `moshi`.`application`.`contentType` AS `contentType`
                                                 from `moshi`.`application`);

