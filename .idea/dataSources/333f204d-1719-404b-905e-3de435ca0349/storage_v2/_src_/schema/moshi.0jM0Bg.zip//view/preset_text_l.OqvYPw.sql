create view preset_text_l as (select `moshi`.`preset_text`.`key`   AS `key`,
                                     `moshi`.`preset_text`.`value` AS `value`,
                                     `moshi`.`preset_text`.`type`  AS `type`
                              from `moshi`.`preset_text`);

