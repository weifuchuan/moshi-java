create definer = root@`%` view auth_code_l as (select `moshi`.`auth_code`.`id`        AS `id`,
                                                      `moshi`.`auth_code`.`accountId` AS `accountId`,
                                                      `moshi`.`auth_code`.`expireAt`  AS `expireAt`,
                                                      `moshi`.`auth_code`.`type`      AS `type`
                                               from `moshi`.`auth_code`);

