create view permission_m as (select `moshi`.`permission`.`id`         AS `id`,
                                    `moshi`.`permission`.`actionKey`  AS `actionKey`,
                                    `moshi`.`permission`.`controller` AS `controller`,
                                    `moshi`.`permission`.`remark`     AS `remark`
                             from `moshi`.`permission`);

