create view subscription_t as (select `moshi`.`subscription`.`id`            AS `id`,
                                      `moshi`.`subscription`.`accountId`     AS `accountId`,
                                      `moshi`.`subscription`.`refId`         AS `refId`,
                                      `moshi`.`subscription`.`subscribeType` AS `subscribeType`,
                                      `moshi`.`subscription`.`createAt`      AS `createAt`,
                                      `moshi`.`subscription`.`cost`          AS `cost`,
                                      `moshi`.`subscription`.`status`        AS `status`
                               from `moshi`.`subscription`);

