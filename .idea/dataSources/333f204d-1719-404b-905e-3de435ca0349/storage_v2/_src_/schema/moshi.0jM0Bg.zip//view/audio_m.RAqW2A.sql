create definer = root@`%` view audio_m as (select `moshi`.`audio`.`id`        AS `id`,
                                                  `moshi`.`audio`.`resource`  AS `resource`,
                                                  `moshi`.`audio`.`recorder`  AS `recorder`,
                                                  `moshi`.`audio`.`accountId` AS `accountId`,
                                                  `moshi`.`audio`.`status`    AS `status`,
                                                  `moshi`.`audio`.`name`      AS `name`,
                                                  `moshi`.`audio`.`uploadAt`  AS `uploadAt`
                                           from `moshi`.`audio`);

