create definer = root@`%` view account_role_l as (select `moshi`.`account_role`.`accountId` AS `accountId`,
                                                         `moshi`.`account_role`.`roleId`    AS `roleId`
                                                  from `moshi`.`account_role`);

