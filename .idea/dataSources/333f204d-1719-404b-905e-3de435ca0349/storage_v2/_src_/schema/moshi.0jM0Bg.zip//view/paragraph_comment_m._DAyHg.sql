create view paragraph_comment_m as (select `moshi`.`paragraph_comment`.`id`          AS `id`,
                                           `moshi`.`paragraph_comment`.`paragraphId` AS `paragraphId`,
                                           `moshi`.`paragraph_comment`.`accountId`   AS `accountId`,
                                           `moshi`.`paragraph_comment`.`content`     AS `content`,
                                           `moshi`.`paragraph_comment`.`createAt`    AS `createAt`,
                                           `moshi`.`paragraph_comment`.`status`      AS `status`,
                                           `moshi`.`paragraph_comment`.`replyTo`     AS `replyTo`
                                    from `moshi`.`paragraph_comment`);

