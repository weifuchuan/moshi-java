create definer = root@`%` view subscribed_count as (select count(0)            AS `count`,
                                                           `s`.`refId`         AS `refId`,
                                                           `s`.`subscribeType` AS `subscribeType`
                                                    from `moshi`.`subscription` `s`
                                                    group by `s`.`refId`, `s`.`subscribeType`);

