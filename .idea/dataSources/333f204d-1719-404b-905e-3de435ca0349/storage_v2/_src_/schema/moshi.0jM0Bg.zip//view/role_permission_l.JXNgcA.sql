create view role_permission_l as (select `moshi`.`role_permission`.`roleId`       AS `roleId`,
                                         `moshi`.`role_permission`.`permissionId` AS `permissionId`
                                  from `moshi`.`role_permission`);

