create definer = root@`%` view course_t as (select `moshi`.`course`.`id`              AS `id`,
                                                   `moshi`.`course`.`accountId`       AS `accountId`,
                                                   `moshi`.`course`.`name`            AS `name`,
                                                   `moshi`.`course`.`introduce`       AS `introduce`,
                                                   `moshi`.`course`.`shortIntro`      AS `shortIntro`,
                                                   `moshi`.`course`.`introduceImage`  AS `introduceImage`,
                                                   `moshi`.`course`.`note`            AS `note`,
                                                   `moshi`.`course`.`createAt`        AS `createAt`,
                                                   `moshi`.`course`.`publishAt`       AS `publishAt`,
                                                   `moshi`.`course`.`buyerCount`      AS `buyerCount`,
                                                   `moshi`.`course`.`courseType`      AS `courseType`,
                                                   `moshi`.`course`.`price`           AS `price`,
                                                   `moshi`.`course`.`discountedPrice` AS `discountedPrice`,
                                                   `moshi`.`course`.`offerTo`         AS `offerTo`,
                                                   `moshi`.`course`.`status`          AS `status`,
                                                   `moshi`.`course`.`lectureCount`    AS `lectureCount`
                                            from `moshi`.`course`);

