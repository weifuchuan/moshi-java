create definer = root@`%` view paragraph_m as (select `moshi`.`paragraph`.`id`        AS `id`,
                                                      `moshi`.`paragraph`.`sectionId` AS `sectionId`,
                                                      `moshi`.`paragraph`.`accountId` AS `accountId`,
                                                      `moshi`.`paragraph`.`vedioId`   AS `vedioId`,
                                                      `moshi`.`paragraph`.`content`   AS `content`,
                                                      `moshi`.`paragraph`.`createAt`  AS `createAt`,
                                                      `moshi`.`paragraph`.`status`    AS `status`
                                               from `moshi`.`paragraph`);

