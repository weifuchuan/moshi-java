create definer = root@`%` view issue_comment_l as (select `moshi`.`issue_comment`.`id`        AS `id`,
                                                          `moshi`.`issue_comment`.`issueId`   AS `issueId`,
                                                          `moshi`.`issue_comment`.`accountId` AS `accountId`,
                                                          `moshi`.`issue_comment`.`createAt`  AS `createAt`,
                                                          `moshi`.`issue_comment`.`content`   AS `content`,
                                                          `moshi`.`issue_comment`.`status`    AS `status`
                                                   from `moshi`.`issue_comment`);

