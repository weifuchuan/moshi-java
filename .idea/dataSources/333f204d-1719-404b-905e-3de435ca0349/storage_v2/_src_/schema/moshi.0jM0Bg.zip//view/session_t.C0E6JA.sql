create definer = root@`%` view session_t as (select `moshi`.`session`.`id`        AS `id`,
                                                    `moshi`.`session`.`accountId` AS `accountId`,
                                                    `moshi`.`session`.`expireAt`  AS `expireAt`
                                             from `moshi`.`session`);

