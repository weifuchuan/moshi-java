create view news_l as (select `moshi`.`news`.`id`          AS `id`,
                              `moshi`.`news`.`title`       AS `title`,
                              `moshi`.`news`.`content`     AS `content`,
                              `moshi`.`news`.`createAt`    AS `createAt`,
                              `moshi`.`news`.`publishAt`   AS `publishAt`,
                              `moshi`.`news`.`status`      AS `status`,
                              `moshi`.`news`.`author`      AS `author`,
                              `moshi`.`news`.`audioId`     AS `audioId`,
                              `moshi`.`news`.`contentType` AS `contentType`
                       from `moshi`.`news`);

