create definer = root@`%` view subscription_l as (select `moshi`.`subscription`.`id`            AS `id`,
                                                         `moshi`.`subscription`.`accountId`     AS `accountId`,
                                                         `moshi`.`subscription`.`refId`         AS `refId`,
                                                         `moshi`.`subscription`.`subscribeType` AS `subscribeType`,
                                                         `moshi`.`subscription`.`createAt`      AS `createAt`,
                                                         `moshi`.`subscription`.`cost`          AS `cost`,
                                                         `moshi`.`subscription`.`status`        AS `status`,
                                                         `moshi`.`subscription`.`payWay`        AS `payWay`
                                                  from `moshi`.`subscription`);

